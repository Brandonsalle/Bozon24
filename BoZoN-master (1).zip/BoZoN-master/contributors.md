## Contributors

- [aledeg](https://github.com/aledeg)
- [ankerfest](https://github.com/ankerfest)
- [Oros42](https://github.com/Oros42)
- [Stéphane - pluxopolis](http://pluxopolis.net/) 
- [JerryWham](http://ecyseo.net/) 

## Special thanks
- [Cyrille Borne](https://github.com/cborne) (http://www.cyrille-borne.com): without your comments, issues reporting and enhancement ideas this app would never have been so complete ;-)
